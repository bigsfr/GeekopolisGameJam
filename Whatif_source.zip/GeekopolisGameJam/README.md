GeekopolisGameJam
=================

The code for the geekopolis game jam



Pour cela il faut installer au cas ou :


http://monogame.codeplex.com/releases/view/102870


http://connect.creativelabs.com/developer/Wiki/OpenAL%20Installer%20for%20Windows.aspx



L'executable est dans bin/Debug

